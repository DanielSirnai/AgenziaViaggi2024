import java.util.*;
class AgenziaViaggi {
    private ArrayList<Volo> voli;

    public AgenziaViaggi() {
        voli = new ArrayList<>();
    }

    public void aggiungiVolo(Volo volo) {
        voli.add(volo);
    }

    public void aggiungiVoloManuale() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Inserisci la destinazione del volo:");
        String destinazione = scanner.nextLine();
        System.out.println("Inserisci la compagnia aerea del volo:");
        String compagnia = scanner.nextLine();
        System.out.println("Il volo � nazionale? (si/no):");
        String nazionaleStr = scanner.nextLine();
        boolean nazionale = nazionaleStr.equalsIgnoreCase("si");
        Volo volo = new Volo(destinazione, compagnia, nazionale);
        aggiungiVolo(volo);
    }

    public void visualizzaVoli(boolean nazionali) {
        for (Volo volo : voli) {
            if ((nazionali && volo.isNazionale()) || (!nazionali && !volo.isNazionale())) {
                System.out.println(volo.toString());
            }
        }
    }

    public void prenotaVolo(int indice) {
        if (indice >= 0 && indice < voli.size()) {
            voli.get(indice).prenota();
        } else {
            System.out.println("Indice non valido");
        }
    }

    public void cancellaPrenotazioneVolo(int indice) {
        if (indice >= 0 && indice < voli.size()) {
            voli.get(indice).cancellaPrenotazione();
        } else {
            System.out.println("Indice non valido");
        }
    }
}