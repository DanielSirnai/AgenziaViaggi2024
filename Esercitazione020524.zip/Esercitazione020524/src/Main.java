import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AgenziaViaggi agenziaViaggi = new AgenziaViaggi();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Men�:");
            System.out.println("1. Aggiungi volo nazionale");
            System.out.println("2. Aggiungi volo internazionale");
            System.out.println("3. Visualizza voli nazionali disponibili");
            System.out.println("4. Visualizza voli internazionali disponibili");
            System.out.println("5. Prenota un volo");
            System.out.println("6. Cancella la prenotazione di un volo");
            System.out.println("7. Esci");
            System.out.print("Scelta: ");
            int scelta = scanner.nextInt();
            scanner.nextLine(); // Consuma il newline

            switch (scelta) {
                case 1:
                    agenziaViaggi.aggiungiVoloManuale();
                    break;
                case 2:
                    agenziaViaggi.aggiungiVoloManuale();
                    break;
                case 3:
                    agenziaViaggi.visualizzaVoli(true);
                    break;
                case 4:
                    agenziaViaggi.visualizzaVoli(false);
                    break;
                case 5:
                    System.out.print("Inserisci l'indice del volo da prenotare: ");
                    int indice = scanner.nextInt();
                    scanner.nextLine(); // Consuma il newline
                    agenziaViaggi.prenotaVolo(indice);
                    break;
                case 6:
                    System.out.print("Inserisci l'indice del volo da cancellare la prenotazione: ");
                    int indicePrenotazione = scanner.nextInt();
                    scanner.nextLine(); // Consuma il newline
                    agenziaViaggi.cancellaPrenotazioneVolo(indicePrenotazione);
                    break;
                case 7:
                    System.out.println("Grazie per aver utilizzato l'applicazione");
                    return;
                default:
                    System.out.println("Scelta non valida");
            }
        }
    }
}