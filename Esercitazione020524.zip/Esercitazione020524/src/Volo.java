import java.util.ArrayList;
import java.util.Scanner;

class Volo {
    private String destinazione;
    private String compagnia;
    private boolean nazionale;
    private boolean prenotato;

    public Volo(String destinazione, String compagnia, boolean nazionale) {
        this.destinazione = destinazione;
        this.compagnia = compagnia;
        this.nazionale = nazionale;
        this.prenotato = false;
    }

    public String getDestinazione() {
        return destinazione;
    }

    public String getCompagnia() {
        return compagnia;
    }

    public boolean isNazionale() {
        return nazionale;
    }

    public boolean isPrenotato() {
        return prenotato;
    }

    public void prenota() {
        prenotato = true;
    }

    public void cancellaPrenotazione() {
        prenotato = false;
    }
    
    public String toString() {
        return "Destinazione: " + destinazione + ", Compagnia: " + compagnia + ", Nazionale: " + nazionale + ", Prenotato: " + prenotato;
    }
}


